package stepDefinitions.common;

import common.ConfigFileReader;
import common.CoreDriver;
import pageObjectLibrary.CreateDealPage;
import pageObjectLibrary.HomePage;
import pageObjectLibrary.LoginPage;

public class CommonStepDef extends CoreDriver{
	public static LoginPage login;
	public static HomePage homePage;
	public static CreateDealPage createDeal;	
	public static ConfigFileReader prop;
	
	public static void initiaizePO() {			
			login = new LoginPage(driver);
			homePage = new HomePage(driver);
			createDeal = new CreateDealPage(driver);
			
		}
	
}


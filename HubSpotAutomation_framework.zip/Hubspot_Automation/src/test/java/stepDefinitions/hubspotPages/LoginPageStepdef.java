package stepDefinitions.hubspotPages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;

import common.CoreDriver;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import stepDefinitions.common.CommonStepDef;

public class LoginPageStepdef extends CommonStepDef{
	
	@Given("Launch Hubspot Url on Chrome Browser")
	public void launch_browser() throws Exception {		
		CoreDriver.launchBrowserSession("Chrome");
		initiaizePO();		
		driver.get(getPropertyValue("browserUrl"));
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		
	}

	
	@When("Enter Valid Username and Password")
	public void enter_Valid_Username_and_Password() {	

		driver.findElement(By.xpath("//a[contains(text(),'Allow')]")).click();
		//login.clickOndecline();
	login.clickOnLoginLink();
	//	driver.navigate().to("https://app.hubspot.com/login?hubs_signup-url=www.hubspot.com/&hubs_signup-cta=homepage-nav-login");
		
		login.enterUsernameAndPassord();
	}

	@When("Click on Login Button")
	public void click_on_Login_Button() {
		login.clickLoginButton();
	}

	@Then("User should navigate to Enter Login Code Page")
	public void user_should_navigate_to_Enter_Login_Code_Page() {
		// Write code here that turns the phrase above into concrete actions
		
	}

	@When("Enter Valid Login code and click on Login button")
	public void enter_Valid_Login_code_and_click_on_Login_button() {
		// Write code here that turns the phrase above into concrete actions
		
	}

	@Then("Hubspot Home Page should be displayed")
	public void hubspot_Home_Page_should_be_displayed() {
		
		
	}
}

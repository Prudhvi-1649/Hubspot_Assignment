package testRunner;

import org.junit.BeforeClass;
import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;

@RunWith(Cucumber.class)
@CucumberOptions(
		 features = "src\\test\\java\\featureFiles\\LoginPage.feature"
		 ,glue={"stepDefinitions"}
		 
		 ,monochrome = true
		, plugin = {"pretty"}
		 )
public class RegressionTestRunner {

	
@BeforeClass
public static void beforeAll() {
	System.out.println("test started");
}
	

}

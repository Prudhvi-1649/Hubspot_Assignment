package common;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CoreDriver {

	public static WebDriver driver;
	private Properties properties;

	public static WebDriver launchBrowserSession(String browserName) throws Exception {
		// Check if parameter passed from TestNG is 'firefox'
		if (browserName.equalsIgnoreCase("Firefox")) {
			// create firefox instance
			System.setProperty("webdriver.gecko.driver", ".\\geckodriver.exe");
			driver = new FirefoxDriver();
			return driver;
		}

		else if (browserName.equalsIgnoreCase("Chrome")) {
			// set path to chromedriver.exe
			ChromeOptions options = new ChromeOptions();
			options.setBinary("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe");
			System.setProperty("webdriver.chrome.driver", "src\\test\\java\\resources\\Drivers\\chromedriver.exe");
			// create chrome instance
			driver = new ChromeDriver(options);
			return driver;
		}
		// Check if parameter passed as 'Edge'
		else if (browserName.equalsIgnoreCase("Edge")) {
			// set path to Edge.exe
			System.setProperty("webdriver.edge.driver", "src\\test\\java\\resources\\Drivers\\MicrosoftWebDriver.exe");
			// create Edge instance
			driver = new EdgeDriver();
			return driver;
		} else {
			// If no browser passed throw exception
			throw new Exception("Browser is not correct");
		}

	}
	
	
		
public  void ConfigFileReader() {
		
		BufferedReader reader;
		try {
			reader = new BufferedReader(new FileReader("src//test//java//resources//Config.properties"));
			properties = new Properties();
			try {
				properties.load(reader);				
				reader.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			throw new RuntimeException(
					"Configuration.properties not found at " + "src//test//java//resources//Config.properties");
		}
	}
	public String getPropertyValue(String propertyName) {
			ConfigFileReader();		
		String propName = properties.getProperty(propertyName);
		if (propName != null)
			return propName;
		else
			throw new RuntimeException("driverPath not specified in the Configuration.properties file.");
	}

	
}

package common;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class ConfigFileReader {
	private Properties properties;
	

	public String getPropertyValue(String propertyName) {
		
		String propName = properties.getProperty(propertyName);
		if (propName != null)
			return propName;
		else
			throw new RuntimeException("driverPath not specified in the Configuration.properties file.");
	}

}

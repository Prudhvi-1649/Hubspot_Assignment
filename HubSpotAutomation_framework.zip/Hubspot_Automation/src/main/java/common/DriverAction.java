package common;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class DriverAction extends CoreDriver {
	public static final String ID = "Id";
	public static final String XPATH = "Xpath";
	public static final String CSS = "Css";
	protected static WebDriver driver = null;
	
	public DriverAction(WebDriver driver){
		this.driver=driver;
	}

	public WebElement getWebElement(String locaterType, String locater) {
		
		switch (locaterType) {
		case ID:
			return driver.findElement(By.id(locater));
		case XPATH:
			return driver.findElement(By.xpath(locater));
		case CSS:
			return driver.findElement(By.cssSelector(locater));
		default:
			return null;
		}

	}

	public boolean enterText(String locaterType, String locater, String textToEnter) {
		getWebElement(locaterType, locater).sendKeys(textToEnter);
		return true;
	}

	public boolean clearText(String locaterType, String locater) {
		getWebElement(locaterType, locater).clear();
		return true;
	}

	public boolean clickOnElement(String locaterType, String locater) {
		getWebElement(locaterType, locater).click();
		return true;
	}
}
package pageObjectLibrary;


import org.openqa.selenium.WebDriver;

import common.DriverAction;

public class CreateDealPage extends DriverAction{

	public CreateDealPage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}

	

	
	
}

package pageObjectLibrary;

import org.openqa.selenium.WebDriver;

import common.DriverAction;

public class HomePage extends DriverAction {

	public HomePage(WebDriver driver) {
		super(driver);
		// TODO Auto-generated constructor stub
	}


	
}

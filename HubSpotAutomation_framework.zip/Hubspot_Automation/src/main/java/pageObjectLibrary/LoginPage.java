package pageObjectLibrary;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import common.DriverAction;

public class LoginPage extends DriverAction {
	public LoginPage(WebDriver driver) {
		super(driver);

	}

	String strUserNameId = "username";
	String strPasswordId = "password";
	String strLoginButtonId = "loginBtn";
	String strDeclineCookiesXpath = "//*[@id='hs-eu-confirmation-button']";
	String strLoginLink = "//a[@class='homepage-nav-login']";

	public boolean clickOndecline() {
		WebElement button = getWebElement(XPATH, strDeclineCookiesXpath);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("arguments[0].click();", button);
		return true;
	}

	public boolean clickOnLoginLink() {
		return clickOnElement(XPATH, strLoginLink);
	}

	public boolean enterUsernameAndPassord() {

		enterText(ID, strUserNameId, getPropertyValue("Username"));
		return enterText(ID, strPasswordId, getPropertyValue("Password"));

	}

	public void clickLoginButton() {
		clickOnElement(ID, strLoginButtonId);

	}
}
